package com.htmlto.img;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HtmlToImageRestTests {

	@Test
	void contextLoads() {
	}

}
