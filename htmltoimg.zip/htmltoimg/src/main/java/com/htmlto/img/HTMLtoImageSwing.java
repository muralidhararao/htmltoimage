package com.htmlto.img;

import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JEditorPane;

public class HTMLtoImageSwing {

  public static void main(String[] args) throws Exception {
    String html = "<html>\n" + 
    		"<body>\n" + 
    		"\n" + 
    		"<h2>The href Attribute</h2>\n" + 
    		"\n" + 
    		"<p>HTML links are defined with the a tag. The link address is specified in the href attribute:</p>\n" + 
    		"\n" + 
    		"<a href=\"https://www.w3schools.com\">Visit W3Schools</a>\n" + 
    		"\n" + 
    		"</body>\n" + 
    		"</html>";
    int width = 800, height = 1000;

    BufferedImage image = GraphicsEnvironment.getLocalGraphicsEnvironment()
        .getDefaultScreenDevice().getDefaultConfiguration()
        .createCompatibleImage(width, height);

    Graphics graphics = image.createGraphics();

    URL url= HTMLtoImageSwing.class.getResource("test.htm");
    
   
    
    JEditorPane jep = new JEditorPane();
    //jep.setContentType("text/html");
    jep.setPage("http://en.wikipedia.org");
    //jep.setText(html);
    jep.setSize(width, height);
    jep.print(graphics);

    ImageIO.write(image, "png", new File("Image.png"));
    
    /*
     ByteArrayOutputStream bos = new ByteArrayOutputStream();
      ImageIO.write(bImage, "jpg", bos );
      byte [] data = bos.toByteArray();
     * */
  }
}
