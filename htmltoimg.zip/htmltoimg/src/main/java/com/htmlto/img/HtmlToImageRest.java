package com.htmlto.img;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pdfcrowd.Pdfcrowd;

@SpringBootApplication
@RestController
public class HtmlToImageRest {

public static void main(String[] args) {
SpringApplication.run(HtmlToImageRest.class, args);
}

@GetMapping("/webtoimg")
public String webtoimg(@RequestParam(value = "imgtype", defaultValue = "png") 
String imgtype, @RequestParam(value = "url", defaultValue = "http://www.google.com") String url) throws IOException {

	try {
        Pdfcrowd.HtmlToImageClient client =
            new Pdfcrowd.HtmlToImageClient("murali_wipro", "d6294b10c972f43935b81b9061dc14f0");
        client.setOutputFormat(imgtype);
        //use convertUrl() for web page or convertFile() for HTML file or convertString() for HTML string
        byte[] image = client.convertUrl(url);
        
        ByteArrayInputStream bis = new ByteArrayInputStream(image);
        BufferedImage bImage2 = ImageIO.read(bis);
        
        ImageIO.write(bImage2, "png", new File("images/webtest.png"));

        /*Write a code to send email to Customers*/
        
        return "success";
    }
    catch(Pdfcrowd.Error error) {
        String msg = String.format("Pdfcrowd Error: %d - %s",
                                   error.getCode(), error.getMessage());
        return "Failed"+msg;
    }
}


@GetMapping("/htmltoimg")
public String htmltoimg(@RequestParam(value = "imgtype", defaultValue = "png") 
String imgtype) throws IOException {

	try {
		String html = "<html>\n" + 
	    		"<body>\n" + 
	    		"\n" + 
	    		"<h2>The href Attribute</h2>\n" + 
	    		"\n" + 
	    		"<p>HTML links are defined with the a tag. The link address is specified in the href attribute:</p>\n" + 
	    		"\n" + 
	    		"<a href=\"https://www.test.com\">Visit test</a>\n" + 
	    		"\n" + 
	    		"</body>\n" + 
	    		"</html>";
		
        Pdfcrowd.HtmlToImageClient client =
            new Pdfcrowd.HtmlToImageClient("murali_wipro", "d6294b10c972f43935b81b9061dc14f0");
        client.setOutputFormat(imgtype);
        byte[] image = client.convertString(html);
        
        ByteArrayInputStream bis = new ByteArrayInputStream(image);
        BufferedImage bImage2 = ImageIO.read(bis);
        
        ImageIO.write(bImage2, "png", new File("images/webtest.png"));

        /*Write a code to send email to Customers*/
        
        return "success";
    }
    catch(Pdfcrowd.Error error) {
        String msg = String.format("Pdfcrowd Error: %d - %s",
                                   error.getCode(), error.getMessage());
        return "Failed"+msg;
    }
}



}
